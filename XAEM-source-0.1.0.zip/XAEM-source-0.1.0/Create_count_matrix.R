## Take the workdir and core arguments
workdir=NULL
args = commandArgs(trailingOnly=TRUE)
for (i in 1:length(args)){
	res=unlist(strsplit(args[i],"="))
	if (res[1]=="workdir") workdir=as.character(res[2])
	if (res[1]=="core") core=as.numeric(res[2])
}

source("/path/to/R/Rsource.R")
options(stringsAsFactors=FALSE)
setwd(workdir)
load("X_matrix.RData")

system("mkdir Ycount")
setwd(paste(workdir,"/Ycount",sep=""))
flist = list.files(workdir,pattern="eqClass.txt",recursive=TRUE,full.names = TRUE)

for(id in 1:length(flist)){ # call crpcount()
cat(id,'\n')
y = NULL
y = crpcount(flist[id])
samplename = paste(y$samplename,".RData",sep="")

save(y,file=samplename)
#Y.count = c(Y.count,samplename=list(y$crpcount))
}


flist = list.files(paste(workdir,"/Ycount/",sep=""),pattern="RData",recursive=TRUE,full.names = TRUE)
npat = sapply(CRP,nrow)   # number of occupancy patterns per clusterloc2 = which(npat>1) 
loc2 = which(npat>1) 
CCRP1 = CCRP[loc2]
Y=NULL
for(id in 1:length(flist))
 {cat(id,'\n')
 load(flist[id])
 if(id==1) Y = y[[1]][loc2]
 if(id>1) #100 samples
  {
  y1 = y[[1]][loc2]
  for(i in 1:length(Y))
   {
   Y[[i]] = cbind(Y[[i]],s=y1[[i]][,'sample1'])
   }
  }
 }
 samplename1 = NULL
for(id in 1:length(flist))
 {
  s.1 = strsplit(flist[id],"/")[[1]]
  s = s.1[length(s.1)]
  s = gsub(".RData","",s)
  samplename1 = c(samplename1,s)
 }

samplename1 = gsub(pattern = "N", replacement = "pq", x = samplename1)
 
# samplename1 = as.numeric(samplename1)
# order1 = as.character(c(1:length(flist)))
 setwd(workdir)
 for(i in 1:length(Y))
 {
 y2 = Y[[i]]
 xloc = grep('N', colnames(y2))
 y2.1 = y2[,-xloc]
 colnames(y2.1) = samplename1
 y3 = cbind(CCRP1[[i]],y2.1)
 Y[[i]] = as.matrix(y3)
 }

save(Y,samplename1,file='Ycount.RData')
