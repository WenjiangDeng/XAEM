## Take the workdir and core arguments
core = 8 ##default
args = commandArgs(trailingOnly=TRUE)
for (i in 1:length(args)){
	res=unlist(strsplit(args[i],"="))
	if (res[1]=="workdir") workdir=as.character(res[2])
	if (res[1]=="core") core=as.numeric(res[2])
}

library(foreach)
library(doParallel)
ncores = detectCores()
nc = min(ncores,core)     # use 8 or 16 as needed!!
cl <- makePSOCKcluster(nc)   #
registerDoParallel(cl)

source("/path/to/R/Rsource.R")

options(stringsAsFactors=FALSE)
setwd(workdir)
load("X_matrix.RData")
load('Ycount.RData')


X.y= Y

fun = function(crpdat, maxiter.X=5, modify=TRUE){
  xloc = grep('N', colnames(crpdat))
  X0 = matrix(crpdat[,xloc], ncol=length(xloc))
  Ymat = crpdat[,-xloc]
  est = AEM(X0, Ymat, maxiter.X=maxiter.X, modify=modify)
  return(est)
}
X.y= Y

EST <- foreach(i= 1:length(X.y)) %dopar% fun(X.y[[i]], maxiter.X=5)

names(EST) = names(X.y)

#save(EST,file="Updated_X.Rdata")


####
#### run add paralog step with X from EST result
####
x.all = list()
X.y=Y
for(i in 1:length(X.y))
{
 x1=x2=NULL
 x1 = EST[[i]]$X
 x.y =  X.y[[i]]
 xloc = grep('N', colnames(x.y))
 colnames(x1) = colnames(x.y)[xloc]
 x.all[[i]] = try(ccrpfun(x1))
}
run.err=NULL
for(i in 1:length(X.y))
 if(class(x.all[[i]])== "try-error")
  run.err=c(run.err,i)

 for(i in run.err)
 {
  x1=x2=NULL
  x1 = EST[[i]]$X
  x.y =  X.y[[i]]
  xloc = grep('N', colnames(x.y))
  colnames(x1) = colnames(x.y)[xloc]
  x.all[[i]] = ccrpfun(x1,clim=5) #clim shoule be smaller, such as 10
 }

#save(x.all, file="One_more_Collapsing_X.RData")

#load("Ycount.Rdata")
#load("One_more_Collapsing_X.RData")
cat("\n...Estimation using AEM algorithm...\n")
X.y=Y
beta.all = list()# use the new X to calculate new beta
for(i in 1:length(X.y))
{
 x2=NULL
 x.y =  X.y[[i]]
 xloc = grep('N', colnames(x.y))
 y = x.y[,-xloc]
 x2 = x.all[[i]]
 beta1 = foreach(j=1:ncol(y)) %dopar% EM(x2,y[,j])
 beta2 = Reduce(rbind,beta1)
 rownames(beta2) = NULL
 beta.all = c(beta.all,list(beta2))
}
#save(beta.all,file="Beta_final_paralog.RData")

## singletons
estfun = function(mat){
CRP.y = mat$crpcount
sum(!(names(CRP.y)==names(CRP))) 
## cluster info
npat = sapply(CRP,nrow)   # number of occupancy patterns per cluster
table(npat)
loc1 = which(npat==1)  # clusters with 1 pattern

TC1 = sapply(CRP.y[loc1],function(x) x[1, ncol(x)])
 names(TC1)=names(CRP.y[loc1])
## single tx
est.all =  c(TC1)
return(est.all)
}

flist = list.files(paste(workdir,"/Ycount/",sep=""),pattern="RData",recursive=TRUE,full.names = TRUE)
result_est=NULL
for(id in 1:length(flist)){ # call crpcount()
load(flist[id])
est1 = estfun(y)# estimation step
result_est = cbind(result_est,est1)
cat(id,'\n')
}


samplename1 = gsub(pattern = "pq", replacement = "N", x = samplename1)
 
colnames(result_est)=samplename1

#save(result_est,file="Est_result_Singletons.Rdata")
 
seq1 = Reduce(cbind,beta.all);seq1=t(seq1)
XAEM_isoform_expression = rbind(result_est,seq1)
#load("X_matrix.RData")
txlength1 = sapply(rownames(XAEM_isoform_expression),function(x){return(median(txlength[strsplit(x," ")[[1]]]))})
tmp.count = data.frame(Length=txlength1,XAEM_isoform_expression)
tmp.count2 = apply(XAEM_isoform_expression*1000,2,function(x)return(x/tmp.count$Length))
tmp.count3 = apply(tmp.count2,2,function(x)return(x/sum(x)))
tmp.count3 = tmp.count3*1000000
xaem.raw.counts = XAEM_isoform_expression
xaem.tpm = tmp.count3
save(xaem.raw.counts,xaem.tpm,file="XAEM_isoform_expression.RData")
system("rm -rf Ycount")
system("rm -rf Ycount.RData")
