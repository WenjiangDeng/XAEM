# Example of generating simulated data of transcripts using polyester packages
rm(list=ls())

args = commandArgs(trailingOnly=TRUE)
fastadir=as.character(args[1])
outdir = as.character(args[2])



library(polyester)

fasta_file = fastadir

# generate reads with coverage of 2
unif.countmat=2*width(fasta)

# generate at least 1000 reads
unif.countmat[unif.countmat<1000]=1000
unif.countmat=as.matrix(unif.countmat)
simulate_experiment_countmat(fasta_file, readmat=unif.countmat, outdir=outdir,error_rate=0.0, strand_specific=FALSE) 
rm(list=ls())

