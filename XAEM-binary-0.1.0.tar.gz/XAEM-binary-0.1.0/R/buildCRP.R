### Build transcript cluster and CRP from simulated data
# Before running this script: 
# 1) generate simulated data of the whole transcriptome using genPolyesterSimulation.R
# 2) run GenTC for the simulated data
# Input: eqClass.txt from results of GenTC

rm(list=ls())

args = commandArgs(trailingOnly=TRUE)
eqClassFn=as.character(args[1])

source("/path/to/R/Rsource.R")

core = 8 #default
library(foreach)
library(doParallel)
ncores = detectCores()
nc = min(ncores,core)     # use 8 or 16 as needed!!
cl <- makePSOCKcluster(nc)   #
registerDoParallel(cl)


#get input from eqClass.txt in the output directory of GenTC
rawmat  = read.table(eqClassFn, header=TRUE, as.is=TRUE, sep='\t')
txlength = rawmat$RefLength
names(txlength) = rawmat$Transcript
txlength = txlength[!duplicated(rawmat$Transcript)]

tx2eqc = tapply(rawmat$eqClass,rawmat$Transcript,c)  ## map: tx --> eqClass 
a = sapply(tx2eqc, length)
#table(a)
eqc2tx = tapply(rawmat$Transcript, rawmat$eqClass,c) ## map: eqClass --> tx

## neighbors of each tx
fn = function(i) {eqc=as.character(tx2eqc[[i]]);
unique(unlist(eqc2tx[eqc]))
}
system.time(NB <- foreach(i=1:length(tx2eqc)) %dopar% fn(i) )  ## about 25sec 
names(NB) = names(tx2eqc)


growfn = function(i,NB) sort(unique(unlist(NB[NB[[i]]])))  ## grow from neighborhood NB
system.time(TC2 <- foreach(i= 1:length(NB)) %dopar% growfn(i, NB))  ## about 22sec
names(TC2) = names(NB)

# TC3 = grow from TC2
system.time(TC3 <- foreach(i= 1:length(NB)) %dopar% growfn(i, TC2))
OTC <- sapply(TC3, paste, collapse=' ') # pasted version
names(OTC) = names(NB)
otcmap = as.list(OTC)
names(otcmap) = names(NB)

#output: list of clusters and tx->cluster map 
clust = names(table(OTC))  # clusters
OTC = strsplit(clust,split=' ')
names(OTC) = clust


#get CRP
system.time(
CRP <- foreach(i=1:length(OTC)) %dopar%{
  myOTC=OTC[i]
  #get binary codes of eqc
  myeqc=unique(unlist(sapply(unlist(myOTC),function(x) tx2eqc[x])))
  #eqc2tx[myeqc]
  bcode=lapply(eqc2tx[myeqc],function(x) as.integer(!is.na(match(unlist(myOTC),x))))
  #bcode
  #get corresponding count
  myCount=lapply(myeqc, function(x){ 
    matchID=match(rawmat$Transcript[rawmat$eqClass==x],unlist(myOTC))
    res=rep(0,length(unlist(myOTC)))
    #res[matchID]=rawmat$Weight[rawmat$eqClass==x] # weird, some cases that tx is not matched with the TC; thus some bcodes can be duplicated
    res[na.omit(matchID)]=rawmat$Weight[rawmat$eqClass==x][!is.na(matchID)]
    return(res)
  })
  #create TC count matrix
  mycrpCount=matrix(unlist(myCount),nrow=length(bcode),ncol=length(unlist(myOTC)),byrow=TRUE)
  colnames(mycrpCount)=unlist(myOTC)
  rownames(mycrpCount)=sapply(bcode, function(x) paste(x,collapse=""))
  
  if (nrow(mycrpCount)>1){ # if there are more than 1 row
    mycrpCount=mycrpCount[order(rownames(mycrpCount)),]
    #check if duplicated rownames
    repID=table(rownames(mycrpCount))
    repID=repID[which(repID>1)]
    if (length(repID)>0){
      rmID=which(rownames(mycrpCount) %in% names(repID))
      sumcrpCount=NULL
      for (j in 1:length(repID)){
        sumcrpCount=rbind(sumcrpCount,colSums(mycrpCount[rownames(mycrpCount) %in% names(repID)[j],]))
      }
      rownames(sumcrpCount)=names(repID)
      mycrpCount=mycrpCount[-rmID,]
      mycrpCount=rbind(mycrpCount,sumcrpCount)
      mycrpCount=mycrpCount[order(rownames(mycrpCount)),]
      mycrpCount=as.matrix(mycrpCount)
    }
  }
  
  #extract CRP matrix
  mycrp=t(t(mycrpCount)/colSums(mycrpCount))
  mycrp
}
)
names(CRP)=names(OTC)

CCRP <- lapply(CRP, ccrpfun)

tx=NULL
for(i in 1:length(CCRP)){ tx=c(tx,unlist(strsplit(colnames(CCRP[[i]])," ")))
}

tx2=tx[duplicated(tx)]

fun1=function(tx){
num=NULL
for(i in 1:length(CCRP)){if(tx %in% unlist(strsplit(colnames(CCRP[[i]])," ")))
{num=c(num,i);}
}
return(num)
}

del_id=NULL
for(i in 1:length(tx2)){
 id1=fun1(tx2[i]);num1=NULL
 for(j in 1:length(id1))
  num1=c(num1,ncol(CRP[[id1[j]]]))
 max1=id1[num1==max(num1)]
 if(length(max1>1))max1=max1[1]
 del_id = c(del_id,id1[-(which(id1 %in% max1))]) 
}
del_id = unique(del_id)

CCRP1 = CCRP[-del_id]
CRP1 = CRP[-del_id]

CRP = CRP1;CCRP = CCRP1

save(CRP,CCRP,txlength,file='X_matrix.RData')

